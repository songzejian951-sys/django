
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm


# 注册表单：基于 Django 用户模型,继承父类，现成的模型表单
class RegisterForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        label="邮箱"
    )


    class Meta:
        model = User
        fields = ["username", "email", "password1", "password2"]


# 登录表单：使用 Django 内置的身份验证表单，继承验证身份的表单
class LoginForm(AuthenticationForm):
    username = forms.CharField(label="用户名")
    password = forms.CharField(
        label="密码",
        widget=forms.PasswordInput
    )
