
from django.urls import path
from . import views

# 空间命名
app_name = "user"

urlpatterns = [
    path("register/", views.register, name="register"),
    path("login/", views.user_login, name="login"),
    path("logout/", views.user_logout, name="logout"),


path(
    "active/<uidb64>/<token>/",
    views.activate,
    name="activate"
),

    
]
