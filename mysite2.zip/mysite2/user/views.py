from django.shortcuts import render

# Create your views here.

from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.models import User
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.core.mail import send_mail
from django.conf import settings
from django.urls import reverse
from .forms import RegisterForm, LoginForm




# 注册
def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            # 创建用户，但暂时不保存
            user = form.save(commit=False)

            # 设置为未激活
            user.is_active = False
            user.save()

            # 生成用户 ID 编码
            uid = urlsafe_base64_encode(
                force_bytes(user.pk)
            )

            # 生成激活令牌
            token = default_token_generator.make_token(user)

            # 生成激活链接
            path = reverse(
                "user:activate",
                kwargs={
                    "uidb64": uid,
                    "token": token,
                }
            )
            link = request.build_absolute_uri(path)

            # 发送激活邮件
            try:
                send_mail(
                    subject="学习平台账户激活",
                    message=(
                        f"你好，{user.username}！\n"
                        f"请点击以下链接激活账户：\n{link}"
                    ),
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[user.email],
                    fail_silently=False,
                )
            except Exception:
                # 邮件发送失败时，账户仍然保持未激活
                messages.error(
                    request,
                    "邮件发送失败，请检查邮箱配置后重试。"
                )
                return redirect("user:login")

            messages.success(
                request,
                "注册成功！请登录邮箱，点击激活链接。"
            )
            return redirect("user:login")

    else:
        form = RegisterForm()

    return render(
        request,
        "register.html",
        {"form": form}
    )




# 邮箱激活
def activate(request, uidb64, token):
    try:
        # 解码用户 ID
        uid = force_str(
            urlsafe_base64_decode(uidb64)
        )

        # 查询用户
        user = User.objects.get(pk=uid)

    except (
        TypeError,
        ValueError,
        OverflowError,
        User.DoesNotExist
    ):
        user = None

    # 验证用户和激活令牌
    if (
        user is not None
        and not user.is_active
        and default_token_generator.check_token(user, token)
    ):
        user.is_active = True
        user.save(update_fields=["is_active"])

        messages.success(
            request,
            "邮箱验证成功，账户已激活，请登录。"
        )
        return redirect("user:login")

    messages.error(
        request,
        "激活链接无效、已失效或账户已经激活。"
    )
    return redirect("user:login")





def user_login(request):
    if request.method == "POST":
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            messages.success(request, "登录成功")
            return redirect("/")
        else:
            messages.error(request,'登陆失败')
    else:
        form = LoginForm(request)
    return render(request, "login.html", {"form": form})


def user_logout(request):
    logout(request)
    messages.success(request, "已退出登录")
    return redirect("/")

