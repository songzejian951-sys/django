

from django.urls import path
from .views import index,detail,contact
# 通过应用自己找到
app_name = "main"


urlpatterns = [
# 自定义路由，可以定义字段传参数,注意斜杠
    path('detail/<int:pk>/',detail,name='detail'),
    path("",index, name="index"),
    path("contact/",contact, name="contact"),
]


