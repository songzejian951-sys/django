
# Create your models here.
from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=100)
    id = models.AutoField(primary_key=True)
    info = models.TextField()

    def __str__(self):
        return self.name


class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    publish_date = models.DateField()

    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE
    )

    def __str__(self):
        return self.title


class Banner(models.Model):
    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to='banners/')
    link = models.CharField(max_length=200, blank=True, default='')
    order = models.IntegerField(default=0)

    def __str__(self):
        return self.title


class Contact(models.Model):
    email = models.EmailField(default='')
    message = models.TextField(default='')

    def __str__(self):
        return self.email



