from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Category,Banner,Contact
# 导入的message用来提醒
from django.contrib import messages

# Create your views here.

#request → 浏览器发给 Django 的请求
#Request  →  Django  →  Response

def index(request):
    # render 最终返回的也是httpResponse 绑定的是自己定义定义的模板，显示页面
    banners = Banner.objects.all()
    cs = Category.objects.all()
    return render(request, 'home.html',{
        'name': '首页',
        'banners': banners,
        'cs': cs
    })


# 从路由传过来的值
def detail(request,pk):
    c = Category.objects.get(pk=pk)
    # 有返回值
    return render(request, 'detail.html',context={"pk":pk,"c":c})



def contact(request):
    if request.method == "GET":
        return render(request, template_name='contact.html')
    else:
        email = request.POST.get("email")
        message = request.POST.get("message")
        print(email, message)
        # 联通数据库
        if email and message:
            c = Contact()
            c.email = email
            c.message = message
            c.save()
            messages.success(request, "已经收到你的数据")
        else:
            messages.error(request, "提交信息有错误")
        return redirect('/contact/')